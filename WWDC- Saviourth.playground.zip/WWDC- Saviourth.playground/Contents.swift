//#-hidden-code

import PlaygroundSupport
import UIKit
import SpriteKit
import AVKit

//end-hidden-code-#


/*:
 
 # Saviourth!
 ## Save the Earth one trash at a time
 */
/*:
 
 ## In this playground you can:
 
 * Point your device's camera towards a trash and find out if it is Bio-Degradable, Recyclable or Non-Recyclable
 * Here are the items that this playground can detect:
    Apple, Banana, Laptop, Lemon, Tomato, Paper, Cardboard, Glass, Plastic, Mobile

 * Play a game to collect trash that is falling from the sky and gain points to help me get to WWDC 2019!
 


 ## Credits:
 * Fruit Image Dataset : Horea Muresan, Mihai Oltean, Fruit recognition from images using deep learning, Acta Univ. Sapientiae, Informatica Vol. 10, Issue 1, pp. 26-42, 2018.
 * Trash Image Dataset : https://github.com/garythung/trashnet
 * Custom Font from daFont.com (theBoldFont) : https://www.dafont.com/the-bold-font.font
 * Impact Sound Effect : https://www.zapsplat.com
 * News Paper Icon : https://www.flaticon.com/free-icon/newspaper_1398780
 * Laptop Icon : https://www.flaticon.com/free-icon/laptop_689355
 * Apple Icon : https://www.flaticon.com/free-icon/apple_135728
 
  */
let master = ViewController()
public let nav = UINavigationController(rootViewController: master)
//nav.preferredContentSize = CGSize(width: 800, height: 400)
//PlaygroundPage.current.wantsFullScreenLiveView = true
//The line above only works on the iPad 
PlaygroundPage.current.liveView = nav


