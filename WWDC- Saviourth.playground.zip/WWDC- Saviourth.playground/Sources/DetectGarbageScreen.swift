import UIKit
import AVKit
import PlaygroundSupport
import Vision




public class NewViewController : UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate{
    
    var previewLayer : AVCaptureVideoPreviewLayer!
    let card = UIView()
    let cardStackView = UIStackView()
    let identityLabel = UILabel()
    let typeLabel = UILabel()
    let descriptionLabel = UILabel()
    let cardImageLabel = UIImageView()
    
    override public func viewDidLoad() {
       // view.backgroundColor = .purple
        navigationController?.isNavigationBarHidden = false
        navigationController?.navigationBar.tintColor = .black
        navigationController?.navigationBar.barTintColor = .orange
        self.navigationItem.title = "What Garbage is This?"
        
        main()
        cardView()
        
    }
    
    public override func viewDidDisappear(_ animated: Bool) {
        navigationController?.isNavigationBarHidden = true
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        
    }
    
    public func main()
    {
        let captureSession = AVCaptureSession()
        guard let captureDevice = AVCaptureDevice.default(for: .video) else {return}
        guard let input = try? AVCaptureDeviceInput(device: captureDevice) else {return}
        captureSession.addInput(input)
        captureSession.sessionPreset = .photo
        
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.frame = self.view.frame
        previewLayer.videoGravity = .resizeAspectFill
        previewLayer.connection?.videoOrientation = .landscapeRight
        captureSession.startRunning()
        self.view.layer.addSublayer(previewLayer)
        
        let dataOutput = AVCaptureVideoDataOutput()
        dataOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        captureSession.addOutput(dataOutput)
    }
    
    public func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        
        
        guard let pixelBuffer : CVPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {return}
        
        
        guard let model = try? VNCoreMLModel(for: WasteSegregationModel().model) else {return}
        let request = VNCoreMLRequest(model: model) { (req, error) in
            
            
            guard let results = req.results as? [VNClassificationObservation] else {return}
            guard let firstObservation = results.first else {return}
            
            
            DispatchQueue.main.async {
                
                
                let confidence = firstObservation.confidence * 100
                if confidence >= 85
                {
                    self.navigationItem.title = "Crunching the numbers"
                    switch firstObservation.identifier
                    {
                        
                    case "laptop" :
                        
                        self.cardImageLabel.image = UIImage(imageLiteralResourceName: "LaptopCard.png")
                        self.cardImageLabel.contentMode = .scaleAspectFit
                        self.descriptionLabel.text = "Electronic wastes qualifies as hazardous waste when discarded. A hazardous waste is a special type of waste because it cannot be disposed of by common means like other by-products of our everyday lives."
                        
                    case "Apple":
                        self.cardImageLabel.image = UIImage(imageLiteralResourceName: "AppleCard.png")
                        self.cardImageLabel.contentMode = .scaleAspectFit
                        self.descriptionLabel.text = "Biodegradable waste is any product that can be easily broken down naturally by water, oxygen, the sun's rays, radiation, or microorganisms. In the process, organic forms of matter are broken down into simpler units. The matter is decomposed and will eventually return to the soil."
                        
                    case "Banana":
                        self.cardImageLabel.image = UIImage(imageLiteralResourceName: "BananaCard.png")
                        self.cardImageLabel.contentMode = .scaleAspectFit
                        self.descriptionLabel.text = "Biodegradable waste is any product that can be easily broken down naturally by water, oxygen, the sun's rays, radiation, or microorganisms. In the process, organic forms of matter are broken down into simpler units. The matter is decomposed and will eventually return to the soil."
                        
                    case "Lemon":
                        self.cardImageLabel.image = UIImage(imageLiteralResourceName: "LemonCard.png")
                        self.cardImageLabel.contentMode = .scaleAspectFit
                        self.descriptionLabel.text = "Biodegradable waste is any product that can be easily broken down naturally by water, oxygen, the sun's rays, radiation, or microorganisms. In the process, organic forms of matter are broken down into simpler units. The matter is decomposed and will eventually return to the soil."
                        
                    case "Mobile":
                        self.cardImageLabel.image = UIImage(imageLiteralResourceName: "MobileCard.png")
                        self.cardImageLabel.contentMode = .scaleAspectFit
                        self.descriptionLabel.text = "Electronic wastes qualifies as hazardous waste when discarded. A hazardous waste is a special type of waste because it cannot be disposed of by common means like other by-products of our everyday lives."
                        
                    case "Paper":
                        self.cardImageLabel.image = UIImage(imageLiteralResourceName: "PaperCard.png")
                        self.cardImageLabel.contentMode = .scaleAspectFit
                        self.descriptionLabel.text = "Recycling is the method used to convert the waste materials into products which can be reused. The common waste materials which have the potential to be reused can be recycled as raw materials, can reduce energy consumption, reduce pollution, reduce further pollution of water and landfills; reducing the need for waste disposal."
                        
                    case "cardboard":
                        self.cardImageLabel.image = UIImage(imageLiteralResourceName: "PaperCard.png")
                        self.cardImageLabel.contentMode = .scaleAspectFit
                        self.descriptionLabel.text = "Recycling is the method used to convert the waste materials into products which can be reused. The common waste materials which have the potential to be reused can be recycled as raw materials, can reduce energy consumption, reduce pollution, reduce further pollution of water and landfills; reducing the need for waste disposal."
                        
                    case "Tomato":
                        self.cardImageLabel.image = UIImage(imageLiteralResourceName: "TomatoCard.png")
                        self.cardImageLabel.contentMode = .scaleAspectFit
                        self.descriptionLabel.text = "Biodegradable waste is any product that can be easily broken down naturally by water, oxygen, the sun's rays, radiation, or microorganisms. In the process, organic forms of matter are broken down into simpler units. The matter is decomposed and will eventually return to the soil."
                        
                    case "plastic":
                        self.cardImageLabel.image = UIImage(imageLiteralResourceName: "PlasticCard.png")
                        self.cardImageLabel.contentMode = .scaleAspectFit
                        self.descriptionLabel.text = "Recycling is the method used to convert the waste materials into products which can be reused. The common waste materials which have the potential to be reused can be recycled as raw materials, can reduce energy consumption, reduce pollution, reduce further pollution of water and landfills; reducing the need for waste disposal."
                        
                    case "glass":
                        self.cardImageLabel.image = UIImage(imageLiteralResourceName: "GlassCard.png")
                        self.cardImageLabel.contentMode = .scaleAspectFit
                        self.descriptionLabel.text = "Recycling is the method used to convert the waste materials into products which can be reused. The common waste materials which have the potential to be reused can be recycled as raw materials, can reduce energy consumption, reduce pollution, reduce further pollution of water and landfills; reducing the need for waste disposal."
                        
                    default :
                        self.cardImageLabel.image = UIImage(imageLiteralResourceName: "IDon'tKnowCard.png")
                        self.descriptionLabel.text = "Point your camera towards an Apple, Banana, Laptop, Mobile, Lemon to find out what type of waste they are Point your camera towards an Apple, Banana, Laptop, Mobile, Lemon to find out what type of waste they are Point your camera towards an Apple, Banana, Laptop, Mobile, Lemon to find out what type of waste they are "
                    }
                    
                }
                
            }
            
            
        }
        try? VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:]).perform([request])
    }
    
    func cardView() {
        
        view.addSubview(card)
        card.layer.cornerRadius = 15
        card.backgroundColor = .white
        
        card.translatesAutoresizingMaskIntoConstraints = false
        card.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 0).isActive = true
        card.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10).isActive = true
        card.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10).isActive = true
        card.heightAnchor.constraint(equalToConstant: view.frame.height/4).isActive = true
        
        identityLabel.adjustsFontSizeToFitWidth = true
        typeLabel.adjustsFontSizeToFitWidth = true
        identityLabel.textAlignment = .center
        identityLabel.font = UIFont.boldSystemFont(ofSize: 50)
        typeLabel.textAlignment = .center
        cardImageLabel.image = UIImage(imageLiteralResourceName: "CardboardCard")
        cardImageLabel.contentMode = .scaleAspectFit
        descriptionLabel.numberOfLines = 0
        identityLabel.text = "Apple"
        
        
        descriptionLabel.text = "Biodegradable waste includes any organic matter in waste which can be broken down into carbon dioxide, water, methane or simple organic molecules by micro-organisms and other living things by composting, aerobic digestion, anaerobic digestion or similar processes. In waste management, it also includes some inorganic materials which can be decomposed by bacteria."


        cardStackView.axis  = .vertical
        cardStackView.distribution  = .fillProportionally
        cardStackView.alignment = .center
        cardStackView.spacing   = 3
        cardStackView.contentMode = .scaleAspectFill
        cardStackView.addArrangedSubview(cardImageLabel)
        cardStackView.addArrangedSubview(descriptionLabel)
        cardStackView.translatesAutoresizingMaskIntoConstraints = false
        

        card.addSubview(cardStackView)
        
 
//        cardStackView.topAnchor.constraint(equalTo: card.topAnchor).isActive = true
        
        cardStackView.centerXAnchor.constraint(equalTo: card.centerXAnchor).isActive = true
        cardStackView.centerYAnchor.constraint(equalTo: card.centerYAnchor).isActive = true
        cardStackView.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: 0).isActive = true
        cardStackView.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 5).isActive = true
        cardStackView.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -5).isActive = true
        
        
        
        
        
    }
    
    
}


