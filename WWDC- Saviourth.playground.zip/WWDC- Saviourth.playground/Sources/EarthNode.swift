//
//  EarthNode.swift
//  3dEarth
//
//  Created by Brian Advent on 03.12.17.
//  Copyright © 2017 Brian Advent. All rights reserved.
//

import SceneKit

class EarthNode: SCNNode {

    override init() {
        super.init()
        self.geometry = SCNSphere(radius: 1)
      self.geometry?.firstMaterial?.diffuse.contents = UIImage(imageLiteralResourceName: "Diffuse.jpg")
  //      self.geometry?.firstMaterial?.specular.contents = UIImage(imageLiteralResourceName: "")
//        self.geometry?.firstMaterial?.emission.contents = UIImage(imageLiteralResourceName: "Emission.png")
//    self.geometry?.firstMaterial?.normal.contents = UIImage(named: "Normal")
        
        self.geometry?.firstMaterial?.shininess = 50
        
        let action = SCNAction.rotate(by: 360 * CGFloat(Double.pi / 180), around: SCNVector3(x:0, y:1, z:0), duration: 12)
        
        let repeatAction = SCNAction.repeatForever(action)
        
        self.runAction(repeatAction)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    
    
}
