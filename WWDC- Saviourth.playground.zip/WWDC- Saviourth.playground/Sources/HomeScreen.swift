import Foundation
import AVKit
import UIKit
import Vision
import SceneKit

var MainAudioPlayer = AVAudioPlayer()


public class ViewController : UIViewController {
    
    let sampleLayer = CALayer()
    let gameButton = UIButton()
    let recyclableButton = UIButton()
    let whatTrashButton = UIButton()
    let stackView = UIStackView()
    let mainView = SCNView()
    let mainTextLabel = UILabel()
    let subtitleTextLabel = UILabel()

    
    override public func viewDidLoad() {
        
        
        navigationItem.title = "Saviourth"
        navigationController?.isNavigationBarHidden = true
        self.view.addSubview(mainView)
        mainView.frame = self.view.bounds
        
        let AssortedMusics = NSURL(fileURLWithPath: Bundle.main.path(forResource: "WWDC", ofType: "m4a")!)
        MainAudioPlayer = try! AVAudioPlayer(contentsOf: AssortedMusics as URL)
        MainAudioPlayer.prepareToPlay()
        MainAudioPlayer.numberOfLoops = -1
        
        
        let cfURL = Bundle.main.url(forResource: "theBoldFont", withExtension: "ttf")! as CFURL
        CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)
        var fontNames: [[AnyObject]] = []
        for name in UIFont.familyNames {
            fontNames.append(UIFont.fontNames(forFamilyName: name) as [AnyObject])
        }
        
        let scene = SCNScene()
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(x:0, y: 0, z: 4)
        
        scene.rootNode.addChildNode(cameraNode)
        
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light?.type = .directional
        lightNode.position = SCNVector3(x: 8, y: 10, z: 2)
        
        scene.rootNode.addChildNode(lightNode)
        
        let stars = SCNParticleSystem(named: "StarsParticles.scnp", inDirectory: nil)!
        
        scene.rootNode.addParticleSystem(stars)
        
        let earthNode = EarthNode()
        earthNode.scale = SCNVector3(0, 0, 0)
        scene.rootNode.addChildNode(earthNode)
        let zoomEarth = SCNAction.scale(to: 1, duration: 2.4)
        let sequence = SCNAction.sequence([zoomEarth])
        earthNode.runAction(sequence)
        
        let sceneView = mainView
        sceneView.scene = scene
        
        sceneView.alpha = 0
        UIView.animate(withDuration: 1.5, animations: {
            sceneView.alpha = 1
        }) { (new) in
            
            MainAudioPlayer.play()
        }
        
        sceneView.showsStatistics = false
        sceneView.backgroundColor = UIColor.black
        sceneView.allowsCameraControl = true
        
        perform(#selector(buttons), with: nil, afterDelay: 2.8)
        
    }
    @objc func buttons () {
        
        
        let horzStackView = UIStackView()
        
        gameButton.setImage(UIImage(imageLiteralResourceName: "CollectCorrectTrashButton.png"), for: .normal)
        recyclableButton.setImage(UIImage(imageLiteralResourceName: "DetectAnObjectButton"), for: .normal)
        
        gameButton.imageView?.contentMode = .scaleAspectFit
        recyclableButton.imageView?.contentMode = .scaleAspectFit
        
        mainTextLabel.text = "Saviourth"
        
        
        
        //Configuring the buttons stack view
        
        horzStackView.spacing = 2
        horzStackView.axis = .horizontal
        horzStackView.alignment = .center
        horzStackView.addArrangedSubview(gameButton)
        horzStackView.addArrangedSubview(recyclableButton)

        
        mainTextLabel.textAlignment = .center
        subtitleTextLabel.textAlignment = .center
        mainTextLabel.textColor = .white
        mainTextLabel.font = UIFont(name:"theBoldFont", size:60)
        mainTextLabel.adjustsFontSizeToFitWidth = true
        subtitleTextLabel.text = "Save the Earth one trash at a time"
        subtitleTextLabel.font = UIFont(name: "theBoldFont", size: 40)
        subtitleTextLabel.numberOfLines = 0
        subtitleTextLabel.textColor = .white
        recyclableButton.addTarget(self, action: #selector(showCameraAlert), for: .touchUpInside)
        gameButton.addTarget(self, action: #selector(showGameAlert), for: .touchUpInside)
        stackView.axis  = .vertical
        stackView.distribution  = .fillEqually
        stackView.alignment = .center
        stackView.spacing   = 10
        stackView.contentMode = .scaleAspectFill
        stackView.addArrangedSubview(mainTextLabel)
        stackView.addArrangedSubview(subtitleTextLabel)
        stackView.addArrangedSubview(horzStackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        
        stackView.alpha = 0
        self.view.addSubview(stackView)
        
        stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true 
        stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor).isActive = true
        stackView.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor).isActive = true 
        stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10)
        stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10)
        
        UIView.animate(withDuration: 1) {
            
            self.stackView.alpha = 1
        }

        
    }
    override public func viewDidAppear(_ animated: Bool) {
        
        navigationController?.isNavigationBarHidden = true
        
        
    }
    
    
    @objc func showCameraAlert()
    {
        let alert = UIAlertController(title: "I want that Power!", message: "Point your camera at an object and tap on the Analyze button on the top left to find out what type of garbage it is", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Let's go!", style: .default, handler: { (action) in
            
            let vc = NewViewController()
            self.navigationController?.pushViewController(vc, animated: true)
            
            
        }))
        present(alert, animated: true, completion: nil)
    }
    
    @objc func showGameAlert() {
        
        let vc = GameViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}

