import SpriteKit


public class MainGameScreen : SKScene {
    
    
    
    //Declaring the Labels
    
    let biodegradLabel = SKLabelNode(fontNamed: "theBoldFont")
    let recyclableLabel = SKLabelNode(fontNamed: "theBoldFont")
    let hazardousLabel = SKLabelNode(fontNamed: "theBoldFont")
    
    //Referencing the Main View Controller
    var viewController : GameViewController!

    var gameArea : CGRect
    override init(size: CGSize) {

        let maxAspectRatio: CGFloat = 4.0/3.0
        let playableWidth = size.width / maxAspectRatio
        let margin = (size.width - playableWidth) / 3
        gameArea = CGRect(x: margin, y: 0, width: playableWidth, height: size.height)
        let touchLocation : CGPoint
        super.init(size: size)

    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override func didMove(to view: SKView) {
        
        
        let cfURL = Bundle.main.url(forResource: "theBoldFont", withExtension: "ttf")! as CFURL
        CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)
        var fontNames: [[AnyObject]] = []
        for name in UIFont.familyNames {
            fontNames.append(UIFont.fontNames(forFamilyName: name) as [AnyObject])
        }
        
        let background = SKSpriteNode(imageNamed: "backgroundsz")
        background.size = self.size
        background.position = CGPoint(x: self.size.width / 2, y: self.size.height / 2)
        background.zPosition = 0
        addChild(background)
        
        let mainLabel = SKLabelNode(fontNamed: "theBoldFont")
        mainLabel.text = "Select a Dustbin"
        mainLabel.position = CGPoint(x: self.frame.midX, y: self.frame.midY + 150)
        mainLabel.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.center
        mainLabel.zPosition = 100
        mainLabel.fontSize = 60
        
        addChild(mainLabel)
        setupGameButtons()
        
        


    }
    

    
    
    func setupGameButtons() {
        

        biodegradLabel.text = "Bio-Degradable"
        biodegradLabel.fontColor = .green
        biodegradLabel.position = CGPoint(x: self.frame.midX, y: self.frame.midY + 50)
        biodegradLabel.zPosition = 100
        biodegradLabel.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.center
        biodegradLabel.fontSize = 50
        addChild(biodegradLabel)
        
        
        recyclableLabel.text = "Recyclable"
        recyclableLabel.fontColor = .blue
        recyclableLabel.position = CGPoint(x: self.frame.midX, y: self.frame.midY - 50)
        recyclableLabel.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.center
        recyclableLabel.zPosition = 100
        recyclableLabel.fontSize = 50
        addChild(recyclableLabel)
        
        
        hazardousLabel.text = "Hazardous"
        hazardousLabel.fontColor = .white
        hazardousLabel.position = CGPoint(x: self.frame.midX, y: self.frame.midY - 150)
        hazardousLabel.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.center
        hazardousLabel.zPosition = 100
        hazardousLabel.fontSize = 50
        addChild(hazardousLabel)
        
        
        
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch : AnyObject in touches {
            
            let pointOfTouch = touch.location(in: self)
            
            if biodegradLabel.contains(pointOfTouch)
            {
                let sceneToMoveTo = BioDegGameScene(size: self.size)
                sceneToMoveTo.scaleMode = self.scaleMode
                let myTransition = SKTransition.fade(withDuration: 0.4)
                let alert = UIAlertController(title: "You've Selected Bio-Degradable", message: "Biodegradable waste includes any organic matter in waste which can be broken down by bacteria. Dustbins that collect Bio-Degradable wastes are usually green in color. Collect the falling apples to gain points", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Let's collect some Apples!", style: .default, handler: { (action) in
                    
                    self.view?.presentScene(sceneToMoveTo, transition: myTransition)
                }))
                alert.addAction(UIAlertAction(title: "Choose something else", style: .default, handler: nil))
                alert.addAction(UIAlertAction(title: "Test", style: .default, handler: { (msz) in
                    
                    self.removeFromParent()
                    self.viewController.navigationController?.popToRootViewController(animated: true)
                    
                }))
                
                self.view?.window?.rootViewController?.present(alert, animated: true, completion: nil)
            }
            else if recyclableLabel.contains(pointOfTouch)
            {
                let sceneToMoveTo = RecyclableGameScene(size: self.size)
                sceneToMoveTo.scaleMode = self.scaleMode
                let myTransition = SKTransition.fade(withDuration: 0.4)
                let alert = UIAlertController(title: "You've selected Recyclable", message: "Recyclable items include Newspapers as the paper can be refined and reused again. In this game you'll have to collect the falling Newspapers and nothing else to get points!", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Let's collect some Newspapers!", style: .default, handler: { (action) in
                    
                    self.view?.presentScene(sceneToMoveTo, transition: myTransition)
                }))
                alert.addAction(UIAlertAction(title: "Choose something else", style: .default, handler: nil))
                
                self.view?.window?.rootViewController?.present(alert, animated: true, completion: nil)
            }
            else if hazardousLabel.contains(pointOfTouch)
            {
                let sceneToMoveTo = DomesticHazGameScene(size: self.size)
                sceneToMoveTo.scaleMode = self.scaleMode
                let myTrasition = SKTransition.fade(withDuration: 0.4)
                
                let alert = UIAlertController(title: "You've selected Hazardous", message: "Hazardous items include electronic wastes and that's why you have to collect laptops and nothing else in the game.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Let's collect some laptops!", style: .default, handler: { (action) in
                    
                    self.view?.presentScene(sceneToMoveTo, transition: myTrasition)
                }))
                alert.addAction(UIAlertAction(title: "Choose something else", style: .default, handler: nil))
                
                self.view?.window?.rootViewController?.present(alert, animated: true, completion: nil)

                
                
            }
        }
    }
}

