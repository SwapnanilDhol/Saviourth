import SpriteKit
import AVKit

let AssortedMusics = NSURL(fileURLWithPath: Bundle.main.path(forResource: "ImpactTrashSound", ofType: "mp3")!)
let ErrorMusic = NSURL(fileURLWithPath: Bundle.main.path(forResource: "ErrorSound", ofType: "mp3")!)

public class DomesticHazGameScene : SKScene, SKPhysicsContactDelegate {
    
    
    let player = SKSpriteNode(imageNamed: "DomesticHaz-TrashCan")
    
    var AudioPlayer = AVAudioPlayer()
    var errorAudioPlayer = AVAudioPlayer()
    var score = 0
    var lives = 3
    let scoreLabel = SKLabelNode()
    let livesLabel = SKLabelNode()
    
    
    struct PhysicsCategories {
        
        static let None : UInt32 = 0
        static let Player : UInt32 = 0b1 //1
        static let Bullet : UInt32 = 0b10 //2
        static let Enemy : UInt32 = 0b100 //4
        static let WrongEnemy : UInt32 = 0b1000 //5
    }
    
    
    func random() -> CGFloat {
        return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
    }
    func random( min: CGFloat, max: CGFloat) -> CGFloat {
        return random() * (max - min) + min
    }
    
    var gameArea: CGRect
    
    override init(size: CGSize) {
        
        let maxAspectRatio: CGFloat = 4.0/3.0
        let playableWidth = size.height / maxAspectRatio
        let margin = (size.width - playableWidth) / 3
        gameArea = CGRect(x: margin, y: 0, width: playableWidth, height: size.height)
        let touchLocation : CGPoint
        super.init(size: size)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

    override public func didMove(to view: SKView) {
        
        self.physicsWorld.contactDelegate = self
        
        let cfURL = Bundle.main.url(forResource: "theBoldFont", withExtension: "ttf")! as CFURL
        CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)
        var fontNames: [[AnyObject]] = []
        for name in UIFont.familyNames {
            fontNames.append(UIFont.fontNames(forFamilyName: name) as [AnyObject])
        }
        
        scoreLabel.fontName = "theBoldFont"
        livesLabel.fontName = "theBoldFont"
        
        AudioPlayer = try! AVAudioPlayer(contentsOf: AssortedMusics as URL)
        AudioPlayer.prepareToPlay()
        errorAudioPlayer = try! AVAudioPlayer(contentsOf: ErrorMusic as URL)
        errorAudioPlayer.prepareToPlay()
        
        let background = SKSpriteNode(imageNamed: "backgroundsz")
        background.size = self.size
        background.position = CGPoint(x: self.size.width / 2, y: self.size.height / 2)
        background.zPosition = 0
        addChild(background)
        
        
        player.setScale(0.5)
        player.position = CGPoint(x: self.size.width / 2, y: self.size.height * 0.2)
        player.zPosition = 2
        player.physicsBody = SKPhysicsBody(rectangleOf: player.size)
        player.physicsBody!.affectedByGravity = false
        player.physicsBody!.categoryBitMask = PhysicsCategories.Player
        player.physicsBody!.collisionBitMask = PhysicsCategories.None
        player.physicsBody?.contactTestBitMask = PhysicsCategories.Enemy
        player.physicsBody?.contactTestBitMask = PhysicsCategories.WrongEnemy
        
        addChild(player)
        addLivesLabel()
        
        addScoreLabel()
        startNewLevel()
        
    }
    
    func addScoreLabel () {
        
        let screenSize = UIScreen.main.bounds
        let screenWidth = screenSize.width
        let screenHeight = screenSize.height
        
        scoreLabel.text = "Score: 0"
        scoreLabel.fontSize = 50
        scoreLabel.fontColor = SKColor.white
        scoreLabel.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.left
        scoreLabel.position = CGPoint(x:self.frame.minX + 150, y:self.frame.maxY - 150)
        scoreLabel.zPosition = 100
        self.addChild(scoreLabel)
        
    }
    
    func addLivesLabel() {
        
        livesLabel.text = "Lives: \(lives)"
        livesLabel.fontSize = 50
        livesLabel.fontColor = SKColor.white
        livesLabel.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.right
        livesLabel.position = CGPoint(x: self.frame.maxX - 100 , y: self.frame.maxY - 150)
        livesLabel.zPosition = 100
        self.addChild(livesLabel)
    }
    
    func loseLife () {
        lives = lives - 1
        livesLabel.text = "Lives: \(lives)"
        let scaleUp = SKAction.scale(to: 1.5, duration: 0.2)
        let scaleDown = SKAction.scale(to: 1, duration: 0.2)
        let scaleSequence = SKAction.sequence([scaleUp, scaleDown])
        livesLabel.run(scaleSequence)
        userLostAllLives()
    }
    
    func addWrongTrash1()
    {
        let trash = SKSpriteNode(imageNamed: "apple")
        //trash.setScale(0.1)
        let actualY = random(min: trash.size.height/2, max: size.height - trash.size.height/2)
        trash.position = CGPoint(x: size.width + trash.size.width/2, y: actualY)
        addChild(trash)
        let actualDuration = random(min: CGFloat(2.0), max: CGFloat(4.0))
        let actionMove = SKAction.move(to: CGPoint(x: -trash.size.width/2, y: actualY),
                                       duration: TimeInterval(actualDuration))
        let actionMoveDone = SKAction.removeFromParent()
        trash.run(SKAction.sequence([actionMove, actionMoveDone]))
        
    }

    
    func addTrash() {
        
        let trash = SKSpriteNode(imageNamed: "laptop")
        let actualY = random(min: trash.size.height/2, max: size.height - trash.size.height/2)
        trash.position = CGPoint(x: size.width + trash.size.width/2, y: actualY)
        addChild(trash)
        let actualDuration = random(min: CGFloat(2.0), max: CGFloat(4.0))
        let actionMove = SKAction.move(to: CGPoint(x: -trash.size.width/2, y: actualY),
                                       duration: TimeInterval(actualDuration))
        let actionMoveDone = SKAction.removeFromParent()
        trash.run(SKAction.sequence([actionMove, actionMoveDone]))
    }
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch: AnyObject in touches {
            
            let pointOfTouch = touch.location(in: self)
            let previosPointOfTouch = touch.previousLocation(in: self)
            let amountDragged = pointOfTouch.x - previosPointOfTouch.x
            player.position.x += amountDragged
            
            if player.position.x > gameArea.maxX - player.size.width/2 {
                player.position.x = gameArea.maxX - player.size.width/2
            }
            if player.position.x < gameArea.minX + player.size.width/2 {
                player.position.x = gameArea.minX + player.size.width/2
            }
            
        }
    }
    
    
    public func didBegin(_ contact: SKPhysicsContact) {
        
        var body1 = SKPhysicsBody()
        var body2 = SKPhysicsBody()
        var body3 = SKPhysicsBody()

        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            
            body1 = contact.bodyA
            body2 = contact.bodyB

            
        }
        else
        {
            body1 = contact.bodyB
            body2 = contact.bodyA
        }
        
        if body1.categoryBitMask == PhysicsCategories.Player && body2.categoryBitMask == PhysicsCategories.Enemy
        {
            AudioPlayer.play()
            body2.node?.removeFromParent()
            addScore()
            
        }
        else if body1.categoryBitMask == PhysicsCategories.Player && body2.categoryBitMask == PhysicsCategories.WrongEnemy
        {
            errorAudioPlayer.play()
            body2.node?.removeFromParent()
            
            loseLife()
        }
        
    }
    func addScore()
    {
        score = score + 1
        scoreLabel.text = "Score: \(score)"
        userGotFullScore()
    }
    
    func userLostAllLives() {
        
        if lives == 0 {
            
            self.removeAllActions()
            let sceneToMoveTo = DomesticHazGameScene(size: self.size)
            sceneToMoveTo.scaleMode = self.scaleMode
            let currentScene = RecyclableGameScene(size: self.size)
            currentScene.scaleMode = self.scaleMode
            let myTrasition = SKTransition.fade(withDuration: 0.4)
            
            let alert = UIAlertController(title: "Oh, No :(", message: "You've lost all your lives. Care to give it another shot? ", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Try Again?", style: .default, handler: { (retry) in
                self.view?.presentScene(currentScene, transition: myTrasition)
                
            }))
            alert.addAction(UIAlertAction(title: "Try another dustbin", style: .default, handler: { (another) in
                
                self.view?.presentScene(sceneToMoveTo, transition: myTrasition)
            }))
            self.view?.window?.rootViewController?.present(alert, animated: true, completion: nil)
        }
        
    }
    
    func startNewLevel () {
        
        let spawn = SKAction.run(generateCorrectTrash)
        let spawnWrongGarbage = SKAction.run(generateWrongTrash)
        let waitToSpawn = SKAction.wait(forDuration: 1)
        let spawnSequence = SKAction.sequence([spawn,waitToSpawn, spawnWrongGarbage, waitToSpawn])
        let spawnForver = SKAction.repeatForever(spawnSequence)
        self.run(spawnForver)
    }
    
    func generateCorrectTrash(){
        
        
        let randomXStart = random(min:gameArea.minX, max: gameArea.maxX)
        let randomXEnd = random(min: gameArea.minX, max:gameArea.maxX)
        
        let startPoint = CGPoint(x: randomXStart, y: self.size.height * 1.2)
        let endPoint = CGPoint(x: randomXEnd, y: -self.size.height * 0.2)
        
        let correctTrash = SKSpriteNode(imageNamed: "laptop")
        correctTrash.setScale(0.2)
        correctTrash.position = startPoint
        correctTrash.zPosition = 2
        correctTrash.physicsBody = SKPhysicsBody(rectangleOf: correctTrash.size)
        correctTrash.physicsBody!.affectedByGravity = false
        correctTrash.physicsBody!.categoryBitMask = PhysicsCategories.Enemy
        correctTrash.physicsBody!.collisionBitMask = PhysicsCategories.None
        correctTrash.physicsBody!.contactTestBitMask = PhysicsCategories.Player
        self.addChild(correctTrash)
        
        let moveEnemy = SKAction.move(to: endPoint, duration: 1.5)
        let deleteEnemy = SKAction.removeFromParent()
        let loseALifeAction = SKAction.run(loseLife)
        let correctTrashSequence = SKAction.sequence([moveEnemy, deleteEnemy, loseALifeAction])
        correctTrash.run(correctTrashSequence)
        
        
        let dy = endPoint.x - startPoint.x
        let dx = endPoint.y - startPoint.y
        let amountToRotate = atan2(dy, dx)
        correctTrash.zRotation = amountToRotate
        
    }
    
    func userGotFullScore()
    {
        if score == 9
        {
            self.removeAllActions()
            self.removeAllChildren()
            let sceneToMoveTo = MainGameScreen(size: self.size)
            let thisScene = DomesticHazGameScene(size: self.size)
            thisScene.scaleMode = self.scaleMode
            sceneToMoveTo.scaleMode = self.scaleMode
            let myTrasition = SKTransition.fade(withDuration: 0.4)
            
            let alert = UIAlertController(title: "You've won the game!", message: "Congratulations! So, to recap: Black Colored dustbins are used for the disposal of Domestic hazardous wastes such as electronic wastes? Want to know if a certain item is a part of this type of waste? Tap on the second button in the home screen!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Play with another type of dustbin", style: .default, handler: { (action) in
                
                self.view?.presentScene(sceneToMoveTo, transition: myTrasition)
            }))
            alert.addAction(UIAlertAction(title: "Play Again", style: .default, handler: { (action) in
            
    self.view?.presentScene(thisScene, transition: myTrasition)
                
                
            }))
            
        }
        
    }
    
    func generateWrongTrash(){
        
        
        let randomXStart = random(min:gameArea.minX, max: gameArea.maxX)
        let randomXEnd = random(min: gameArea.minX, max:gameArea.maxX)
        
        let startPoint = CGPoint(x: randomXStart, y: self.size.height * 1.2)
        let endPoint = CGPoint(x: randomXEnd, y: -self.size.height * 0.2)
        
        let correctTrash = SKSpriteNode(imageNamed: "newspaper")
        correctTrash.setScale(0.2)
        correctTrash.position = startPoint
        correctTrash.zPosition = 2
        correctTrash.physicsBody = SKPhysicsBody(rectangleOf: correctTrash.size)
        correctTrash.physicsBody!.affectedByGravity = false
        correctTrash.physicsBody!.categoryBitMask = PhysicsCategories.WrongEnemy
        correctTrash.physicsBody!.collisionBitMask = PhysicsCategories.None
        correctTrash.physicsBody!.contactTestBitMask = PhysicsCategories.Player
        self.addChild(correctTrash)
        
        let moveEnemy = SKAction.move(to: endPoint, duration: 1.5)
        let deleteEnemy = SKAction.removeFromParent()
        let correctTrashSequence = SKAction.sequence([moveEnemy, deleteEnemy])
        correctTrash.run(correctTrashSequence)
        
        let dy = endPoint.x - startPoint.x
        let dx = endPoint.y - startPoint.y
        let amountToRotate = atan2(dy, dx)
        correctTrash.zRotation = amountToRotate
        
    }
    
}
