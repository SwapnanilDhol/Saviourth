import Foundation
import UIKit
import SpriteKit
import SceneKit

public class GameViewController : UIViewController {
    
    var viewController : GameViewController!

    override public func viewDidLoad() {
        super.viewDidLoad()

        navigationController?.isNavigationBarHidden = false
        navigationController?.navigationBar.backItem?.title = "Home"
        navigationController?.navigationBar.barTintColor = .black
        navigationController?.navigationItem.backBarButtonItem?.tintColor = .orange
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
        
        let widthOfParent = self.view.frame.width
        let heightOfParent = self.view.frame.height
        self.view = SKView()
        let skView = self.view as! SKView
            
            let scene = MainGameScreen(size: CGSize(width: widthOfParent, height: heightOfParent))
        
        if let gameScene = scene as? MainGameScreen {
            
            gameScene.viewController = self
        }
            scene.scaleMode = .aspectFill
            skView.presentScene(scene)
            skView.ignoresSiblingOrder = true
        }


}


